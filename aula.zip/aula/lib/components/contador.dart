import 'package:flutter/material.dart';

class ContadorComponents extends StatelessWidget {
  const ContadorComponents({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      width: double.infinity,
      color: Colors.deepPurple,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text("0", style: TextStyle(fontSize: 100)),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton.icon(
                  onPressed: () {},
                  icon: Icon(Icons.exposure_minus_1_rounded),
                  label: Text("Subtrai 1")),
              ElevatedButton.icon(
                  onPressed: () {},
                  icon: Icon(Icons.plus_one_rounded),
                  label: Text("Adiciona 1")),
            ],
          )
        ],
      ),
    );
  }
}
