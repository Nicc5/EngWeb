package com.example.aula

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
